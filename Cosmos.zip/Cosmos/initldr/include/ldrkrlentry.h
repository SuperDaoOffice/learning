#ifndef LDRKRLENTRY_H
#define LDRKRLENTRY_H



void ldrkrl_entry();

void kerror(char_t* kestr);
void die(u32_t dt);
#endif // LDRKRLENTRY_H
